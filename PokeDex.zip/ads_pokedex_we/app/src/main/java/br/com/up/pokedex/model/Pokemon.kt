package br.com.up.pokedex.model

data class Pokemon(
    val url : String,
    val name : String
)
