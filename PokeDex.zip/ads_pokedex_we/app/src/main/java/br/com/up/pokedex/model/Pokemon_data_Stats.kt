package br.com.up.pokedex.model

data class Pokemon_data_Stats(
    val base_stat: Int,
    val effort: Int,
    val weight: Float

)
