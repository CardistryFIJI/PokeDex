package br.com.up.pokedex.model

data class Pokemon_data(
    val abilities: List<Pokemon_data_Abilities>,
    val moves: List<Pokemon_data_Moves>,
    val stats: List<Pokemon_data_Stats>




)
