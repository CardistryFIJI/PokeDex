package br.com.up.pokedex.model

data class Pokemon_data_Moves(
    val name : String
)
