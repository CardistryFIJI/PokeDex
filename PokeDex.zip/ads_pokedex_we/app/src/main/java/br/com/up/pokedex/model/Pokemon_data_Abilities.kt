package br.com.up.pokedex.model

data class Pokemon_data_Abilities(
    val name : String
)
